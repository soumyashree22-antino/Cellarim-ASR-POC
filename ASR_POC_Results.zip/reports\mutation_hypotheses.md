# WP4 — Mutation / Stability Hypotheses

Target family: **lipase**

Benchmark mean contact density: 5.016

- **ALT_Node15_alt2**: Rg=20.74 Å, contacts/res=3.976, mean pLDDT=37.0 → lower packing — verify fold integrity.
- **ANC_Node15**: Rg=20.76 Å, contacts/res=4.014, mean pLDDT=36.1 → lower packing — verify fold integrity.
- **ALT_Node14_alt3**: Rg=20.45 Å, contacts/res=3.919, mean pLDDT=38.7 → lower packing — verify fold integrity.
