# Scientific Report � Top 3 Candidates (lipase)

Generated: 2026-05-29T09:25:21.359022+00:00

All numbers are computed locally (ESM-2 embeddings + ESMFold + motif/conservation checks). See `reports/candidate_signals.csv` for the full audit trail.

## #1 � `ALT_Node52_alt2`

**Final score:** 0.7913  �  length 1761 aa  �  cluster 0

| Signal | Value |
|---|---|
| Anchor cosine (emb_sim) | 0.9888 |
| ESMFold pLDDT/100 (struct_conf) | 0.6005 |
| Catalytic motif | 1.0 |
| Conservation match | 0.044 |
| ASR uncertainty penalty | 0.0 |
| Packing vs benchmarks | 0.3984 |

**Nearest extant lipases:** P06858 (cos=0.9801), O46647 (cos=0.9795), P07867 (cos=0.9793)

**Interpretation:** ESMFold confidence is moderate; the catalytic motif is intact; the sequence sits firmly on the family manifold (ESM-2).

## #2 � `ALT_Node47_alt3`

**Final score:** 0.7647  �  length 1736 aa  �  cluster 3

| Signal | Value |
|---|---|
| Anchor cosine (emb_sim) | 0.9767 |
| ESMFold pLDDT/100 (struct_conf) | 0.5985 |
| Catalytic motif | 1.0 |
| Conservation match | 0.044 |
| ASR uncertainty penalty | 0.0 |
| Packing vs benchmarks | 0.3984 |

**Nearest extant lipases:** O22527 (cos=0.9599), F4JFU8 (cos=0.959), P06607 (cos=0.9511)

**Interpretation:** ESMFold confidence is moderate; the catalytic motif is intact; the sequence sits firmly on the family manifold (ESM-2).

## #3 � `ALT_Node4_alt1`

**Final score:** 0.6653  �  length 1946 aa  �  cluster 1

| Signal | Value |
|---|---|
| Anchor cosine (emb_sim) | 0.9768 |
| ESMFold pLDDT/100 (struct_conf) | 0.5975 |
| Catalytic motif | 1.0 |
| Conservation match | 0.0899 |
| ASR uncertainty penalty | 0.0 |
| Packing vs benchmarks | 0.3984 |

**Nearest extant lipases:** O22527 (cos=0.9705), A8PUY1 (cos=0.9574), F4JFU8 (cos=0.9509)

**Interpretation:** ESMFold confidence is moderate; the catalytic motif is intact; the sequence sits firmly on the family manifold (ESM-2).
